//
//  EvergreenOakView.swift
//  FP_00657106
//
//  Created by User13 on 2021/1/7.
//

import SwiftUI

struct EvergreenOakView: View {
    @EnvironmentObject var fetch: FetchToDo
    var index: Int
    var body: some View {
        ScrollView(.vertical) {
            VStack {
                Text(fetch.datas[index].common_name)
                    .font(.title)
                    .fontWeight(.bold)
            }
        }
    }
}
struct EvergreenOakView_Previews: PreviewProvider {
    static var previews: some View {
        EvergreenOakView(index: Int).environmentObject(self.fetch)

    }
}

