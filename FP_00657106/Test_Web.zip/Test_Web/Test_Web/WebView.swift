//
//  WebView.swift
//  Test_Web
//
//  Created by User13 on 2020/12/2.
//
import SwiftUI
import WebKit
struct WebView: UIViewRepresentable {
    typealias UIViewType = WKWebView
    
    func makeUIView(context: Context) -> WKWebView {
            let webView = WKWebView()
            if let url = URL(string: "https://www.thelittleprince.com") {
                let request = URLRequest(url: url)
                webView.load(request)
            }
           
            return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
    }
    
}
