//
//  ContentView.swift
//  FP_00657106
//
//  Created by User13 on 2020/12/30.
//

import SwiftUI
struct SearchResponse: Codable {
    let data: [StoreItem]
}

struct StoreItem: Codable, Identifiable {
   let id: Int
   let common_name:String
   let scientific_name:String
   let image_url: URL

}

   
class FetchToDo: ObservableObject {
  @Published var datas = [StoreItem]()
     
    init() {
        let url = URL(string: "https://trefle.io/api/v1/plants?token=8lQEgEoqdUm0p98CJ8H29SEm_90xxUZDFVn-rOlZTrA")!
        URLSession.shared.dataTask(with: url) {(data, response, error) in
            do {
                if let todoData = data {
                    let decodedData = try JSONDecoder().decode(SearchResponse.self, from: todoData)
                    DispatchQueue.main.async {
                        self.datas = decodedData.data
                    }
                } else {
                    print("No data")
                }
            } catch {
                print(error)
            }
        }.resume()
    }
}


struct ContentView: View {
    @ObservedObject var fetch = FetchToDo()
    @State private var showingAddItemView = false

    var body: some View {
        NavigationView {
                ForEach(fetch.datas.indices, id: \.self) { index in
                    NavigationLink(destination: EvergreenOakView(index: index).environmentObject(self.fetch)) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(self.fetch.datas[index].common_name)
                                    .font(.headline)
                            }
                            .frame(maxWidth: 200, maxHeight: 100)
                        }
                    }
                }
            }

        
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

