//
//  Test_WebApp.swift
//  Test_Web
//
//  Created by User13 on 2020/12/2.
//

import SwiftUI

@main
struct Test_WebApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
