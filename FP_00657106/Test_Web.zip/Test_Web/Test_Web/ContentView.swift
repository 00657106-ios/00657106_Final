//
//  ContentView.swift
//  Test_Web
//
//  Created by User13 on 2020/12/2.
//

import SwiftUI
struct ImagePickerController: UIViewControllerRepresentable {
    
    @Binding var showSelectPhoto: Bool
    @Binding var selectImage: Image
    typealias UIViewControllerType = UIImagePickerController
    
    func makeCoordinator() -> Coordinator {
        Coordinator(imagePickerController: self)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let controller = UIImagePickerController()
        controller.sourceType = .photoLibrary
        controller.delegate = context.coordinator
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        
    }
     
    class Coordinator: NSObject, UIImagePickerControllerDelegate,
                       UINavigationControllerDelegate {
        internal init(imagePickerController:
                        ImagePickerController) {
            self.imagePickerController = imagePickerController
        }
        
        let imagePickerController: ImagePickerController
        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info:
                                    [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                imagePickerController.selectImage = Image(uiImage:
                                                            uiImage)
            }
            imagePickerController.showSelectPhoto = false
            
        }
        
    }
}

struct ContentView: View {
    @State private var selectImage = Image(systemName: "photo")
    @State private var showSelectPhoto = false
    
    var body: some View {
        
        Button(action: {
            showSelectPhoto = true
        }) {
            selectImage
                .resizable()
                .scaledToFill()
                .frame(width: 200, height: 200)
                .clipped()
            
        }
        .sheet(isPresented: $showSelectPhoto) {
            ImagePickerController(showSelectPhoto: self.$showSelectPhoto, selectImage: $selectImage)
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
