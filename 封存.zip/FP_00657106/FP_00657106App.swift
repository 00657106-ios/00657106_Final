//
//  FP_00657106App.swift
//  FP_00657106
//
//  Created by User13 on 2020/12/30.
//

import SwiftUI

@main
struct FP_00657106App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
